from django.apps import AppConfig


class Apiv3Config(AppConfig):
    name = "apiv3"
