from django.contrib import admin

from .models import AutomatedTask

admin.site.register(AutomatedTask)
