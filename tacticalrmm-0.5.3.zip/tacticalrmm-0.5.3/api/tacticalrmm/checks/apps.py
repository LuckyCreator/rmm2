from django.apps import AppConfig


class ChecksConfig(AppConfig):
    name = "checks"
