from django.apps import AppConfig


class WinupdateConfig(AppConfig):
    name = "winupdate"
