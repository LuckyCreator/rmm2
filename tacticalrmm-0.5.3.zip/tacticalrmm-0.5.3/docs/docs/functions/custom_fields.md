# Custom Fields

**Settings > Global Settings > Custom Fields**

v0.5.0 adds support for custom fields to be used in scripts.

It also exposes some pre-defined fields that are already in the database.

Please check the following video for examples until proper docs are written:

[https://www.youtube.com/watch?v=0-5jGGL3FOM](https://www.youtube.com/watch?v=0-5jGGL3FOM)




  