# User Interface Preferences

Click on your username at the top right of the dashboard > Preferences:

![user_prefs](../images/user_prefs.png)


![user_prefs2](../images/user_prefs2.png)