wevtutil cl "Microsoft-Windows-Windows Defender/Operational" 
Write-Output "Logs are cleared and RMM status should be reset"
