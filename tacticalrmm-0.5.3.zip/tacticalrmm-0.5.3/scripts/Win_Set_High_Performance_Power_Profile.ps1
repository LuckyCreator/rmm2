Start-Process -FilePath 'powercfg.exe' -ArgumentList '/setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c'
